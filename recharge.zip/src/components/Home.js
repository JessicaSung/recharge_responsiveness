import React, { Component } from 'react';

export default class Home extends Component {
    render() {
        return (
            <div>
                <img className='map mapsize'src='./images/hospitals.png'/>
            </div>
        )
    }
}